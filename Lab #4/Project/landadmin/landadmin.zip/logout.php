<?
setcookie("login" ,'zero',time()+3600*24, "/");

header('location: index.php');



?>