<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?
include('db_connect.php')

?>


<div id="menu">
	<ul>
	<a href="land_header.php"><li>Header</li></a>
	<a href="services.php"><li>Services</li></a>
	<a href="preview.php"><li>Preview product</li></a>
	<a href="numbers.php"><li>Numbers</li></a>
	<a href="prices.php"><li>Prices</li></a>
	<a href="clients.php"><li>Clients</li></a>
	<a href="review.php"><li>Review</li></a>
	<a href="footer.php"><li>Footer</li></a>
	<a href="rights.php"><li>Rights</li></a>
	
</ul>
<div id="all_default">
	<a href="default.php">Load total default</a>
</div>
</div>

</body>
</html>