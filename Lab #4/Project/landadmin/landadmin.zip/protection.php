<?
$log="admin";
$pass=md5("pass");


?>